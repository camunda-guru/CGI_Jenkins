﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            #if DebugConfig  
                 Console.WriteLine("WE ARE IN THE DEBUG CONFIGURATION");  
            #endif
            Console.WriteLine("Testing .NET and Jenkins Integration using MSBUILD and GIT");
        }
    }
}
