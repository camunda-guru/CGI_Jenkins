package com.niit.travel.mocktests;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.niit.travel.entities.Country;
import com.niit.travel.facades.IDataManager;
import com.niit.travel.services.DataManagerService;
@RunWith(EasyMockRunner.class)
public class DataManagerMockTest {
	private static Country country;
	//step 1 create the mock object
	@TestSubject
	private DataManagerService dataManagerService=new DataManagerService();
	
	@Mock
	IDataManager iDataManager;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		country =new Country();
		country.setCountryId("CN");
		country.setName("Canada");
	}

	@Test
	public void addCountryTest() {
		//step2 set the expectation
		EasyMock.expect(iDataManager.addCountry(country)).andReturn("Record Added");
		
		//step3match the expected with actual
		EasyMock.replay( iDataManager);
		assertThat(dataManagerService.addCountry(country),is("Record Added"));
	}
	
	@Test
	public void getCountryByIdTest()
	{
		//step2 set the expectation
				EasyMock.expect(iDataManager.getCountryById("CN")).andReturn(country);
				
				//step3match the expected with actual
				EasyMock.replay( iDataManager);
				assertThat(dataManagerService.getCountryById("CN"),is(country));
	}

}
