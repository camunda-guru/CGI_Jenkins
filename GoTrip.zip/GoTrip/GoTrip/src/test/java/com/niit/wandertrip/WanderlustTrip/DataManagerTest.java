package com.niit.wandertrip.WanderlustTrip;

import static org.junit.Assert.*;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.isA;
import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.niit.travel.dao.DataManager;
import com.niit.travel.entities.Country;


public class DataManagerTest {
	
	private static Country country;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		country =new Country();
		country.setCountryId("CN");
		country.setName("Canada");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void addCountryPositiveTest() throws SQLException {
	
	     assertEquals("record added",new DataManager().addCountry(country));
	}

	@Test
	public void addCountryNegativeTest()  {
	//No SQL exception
	     assertEquals("duplicate keys found",new DataManager().addCountry(country));
	}
	
	
	@Test
	public void getCountriesPositiveTest() throws SQLException {
		
		Country countryObj =new DataManager().getCountries().get(0);
		  assertThat(countryObj, hasProperty("countryId"));
		  assertThat(countryObj, hasProperty("name"));
		  assertThat(new DataManager().getCountries().size(),greaterThan(0));
		  assertThat(new DataManager().getCountries(),hasItem(isA(Country.class)));
	}
	
	
}
