package com.niit.wandertrip.WanderlustTrip;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.niit.travel.dao.DataManager;
import com.niit.travel.entities.Country;
import com.niit.travel.entities.State;
@RunWith(value=Parameterized.class)
public class DataManager_State_Test {

	private  State state;
	private Country country;
	private String stateId;
	private String stateName;
	private String countryCode;
	private String expected;
	
	public DataManager_State_Test(String pexpected,String pstateId, String pstateName, String pcountryCode)
	{
		super();
		this.expected=pexpected;
		this.stateId=pstateId;
		this.stateName=pstateName;
		this.countryCode=pcountryCode;
	}
	
	
	@Parameters(name = "{index}: get({1},{2},{3}) = {0}")
	public static Collection <Object[]> getTestParameters() {
		return Arrays.asList (new Object[][] {
				new Object[] {"Record Added","UP", "Uttar Pradesh","IN"},
				new Object[] {"Record Added","HP", "Himachal Pradesh","IN"},
				new Object[] {"Record Added","MH", "Maharashtra","IN"},
				new Object[] {"Record Added","CH", "Chandigarh","IN"}
				});
	}

	

	@Test
	public void testaddState_positive() {
	   state=new State();
	  state.setStateId(stateId);	
	  state.setStateName(stateName);
	  country = new DataManager().getCountryById(countryCode);
		state.setCountry(country);
		assertThat(expected, is(new DataManager().addState(state)));
	}

}
