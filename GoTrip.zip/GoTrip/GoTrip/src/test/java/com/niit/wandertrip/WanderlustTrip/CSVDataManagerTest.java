package com.niit.wandertrip.WanderlustTrip;

import static org.junit.Assert.*;

import org.junit.Test;

import com.niit.travel.dao.CSVDataManager;

public class CSVDataManagerTest {

	@Test
	public void test() {
		assertEquals("Record Added",new CSVDataManager().addCustomers());
	}

}
