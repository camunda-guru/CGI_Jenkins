package com.niit.wandertrip.WanderlustTrip;

import static org.junit.Assert.*;

import java.io.EOFException;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;

import com.niit.travel.dao.ObjectManager;
import com.niit.travel.entities.Passenger;

public class ObjectManagerTest {

	private static Passenger passenger;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	 passenger = new Passenger();
	 passenger.setFirstName("Bala");
	 passenger.setLastName("Manickamuthu");
	 passenger.setDOB(new Date(65,3,27));
	 passenger.setAadharCardNo("A4395694365");
	}
	@Test
	public void testaddPassenger() {
		assertEquals("Passenger Added", ObjectManager.addPassenger(passenger));
	}
	@Test(expected=NullPointerException.class)
	public void testgetPassengers() {
	
		assertTrue(ObjectManager.getPassengers().size()>0);
	}

}
