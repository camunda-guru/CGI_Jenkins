package com.niit.wandertrip.WanderlustTrip;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.niit.travel.dao.ConnectionHelper;

public class ConnectionHelperTest  {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Called Before Class");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Called After Class");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Called Before every Test");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Called After every Test");
	}

	@Test
	public void getConnectionTest() {
		Assert.assertNotNull(ConnectionHelper.getConnection());
	}
	
}
