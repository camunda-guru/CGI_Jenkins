package com.niit.travel.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import com.niit.travel.entities.Country;
import com.niit.travel.entities.Customer;
import com.niit.travel.entities.State;
import com.niit.travel.facades.IDataManager;

public class DataManager implements IDataManager{

	private Connection con;
	private CallableStatement callableStatement;
	private boolean status;
	private ResultSet resultSet;
	
	public DataManager()
	{
		con=ConnectionHelper.getConnection();
		
	}
	
	public String addCountry(Country country) 
	{
		
		String message=null;
		String addCountry= "{call wanderlustdb.add_country(?,?,?)}";
		
			
			try {
				callableStatement = con.prepareCall(addCountry);
				callableStatement.setString(1, country.getCountryId()); 
				callableStatement.setString(2, country.getName()); 
				callableStatement.registerOutParameter(3,  java.sql.Types.VARCHAR);
				
				// execute add country stored procedure
				callableStatement.execute();
				message = callableStatement.getString(3);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		

		
		
	
	

		return message;
}
	
	public List<Country> getCountries()
	{
		List<Country> countryList=new ArrayList<Country>();
		Country country=null;
		String getCountry= "{call wanderlustdb.get_country()}";
		
		
		try {
			callableStatement = con.prepareCall(getCountry);
			// execute get country stored procedure
			resultSet=callableStatement.executeQuery();
			while(resultSet.next())
			{
				country=new Country();
				country.setCountryId(resultSet.getString(1));
				country.setName(resultSet.getString(2));
				countryList.add(country);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
		return countryList;
		
		
		
	}
	
	public Country getCountryById(String Id)
	{
String getCountryById= "{call  wanderlustdb.get_CountryById(?)}";
		
Country	country=null;
		try {
			callableStatement = con.prepareCall(getCountryById);
			callableStatement.setString(1, Id); 
			// execute get country stored procedure
			
			resultSet=callableStatement.executeQuery();
			resultSet.next();
			
			country=new Country();
				country.setCountryId(resultSet.getString(1));
				country.setName(resultSet.getString(2));
		
				
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return country;
	}
	
	
	public String addState(State state) 
	{
		
		String message=null;
		String addState= "{call wanderlustdb.add_State(?,?,?,?)}";
		
			
			try {
				callableStatement = con.prepareCall(addState);
				callableStatement.setString(1, state.getStateId()); 
				callableStatement.setString(2, state.getStateName()); 
				callableStatement.setString(3, state.getCountry().getCountryId()); 
				callableStatement.registerOutParameter(4,  java.sql.Types.VARCHAR);
				
				// execute add country stored procedure
				callableStatement.execute();

				message = callableStatement.getString(4);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

		
		
	
	

		return message;
}
	
	
	public String addCustomers(Customer customer)
	{
		 
	     
	     String addCustomer= "{call wanderlustdb.sp_addCustomer(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		String message=null;
		
				
				try
				{
					callableStatement = con.prepareCall(addCustomer);
				callableStatement.setString(1, customer.getEmail());//email
				callableStatement.setString(2, customer.getUserName());//username
				callableStatement.setString(3, customer.getFirstName());//fname
				callableStatement.setString(4, customer.getLastName());//lname
				callableStatement.setString(5, customer.getPassword());//password
				callableStatement.setString(6, customer.getGender().toString());//gender			
				
				callableStatement.setDate(7, new java.sql.Date(customer.getDob().getYear(),customer.getDob().getMonthValue(),customer.getDob().getDayOfMonth()));
				callableStatement.setString(8, customer.getNationality());//nationality
				callableStatement.setString(9, customer.getAddress());//address	
				callableStatement.setString(10,customer.getCity());//city
				callableStatement.setString(11, customer.getState());//state
				callableStatement.setString(12, customer.getCountry());//country		
				callableStatement.setString(13, customer.getMobileNo());//mobile no
				callableStatement.setString(14, customer.getPinCode());//pinCode
				callableStatement.setString(15, customer.getRole().toString());//role					
			    
				
			
			
			callableStatement.execute();
			message="Record Added";
			
		} 
	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return message;
	}	
	
}
