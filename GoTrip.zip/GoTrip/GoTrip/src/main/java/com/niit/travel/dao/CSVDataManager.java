package com.niit.travel.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

public class CSVDataManager {
	

	private Connection con;
	private CallableStatement callableStatement;
	private boolean status;
	private ResultSet resultSet;
	private String message;
	public CSVDataManager() {
		con=ConnectionHelper.getConnection();
	}
	
	
	public String addCustomers()
	{
		 String line = "";
	     String cvsSplitBy = ",";		
	     String[] data=null;
	     SimpleDateFormat sformat=new SimpleDateFormat("yyyy-MM-dd");
	     
	     String addCustomer= "{call wanderlustdb.sp_addCustomer(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		ResourceBundle rb = ResourceBundle.getBundle("wandertripdb");
		try {
			BufferedReader bReader=new BufferedReader(new FileReader(rb.getString("path")));
			callableStatement = con.prepareCall(addCustomer);
			while((line=bReader.readLine())!=null)
			{
				
				data=line.split(cvsSplitBy);
							
				Date dob =  sformat.parse(data[7]);
				
				
				System.out.println(dob.toLocaleString());
				
				
			
				callableStatement.setString(1, data[0]);//email
				callableStatement.setString(2, data[2]);//username
				callableStatement.setString(3, data[3]);//fname
				callableStatement.setString(4, data[4]);//lname
				callableStatement.setString(5, data[5]);//password
				callableStatement.setString(6, data[6]);//gender			
				
				callableStatement.setDate(7, new java.sql.Date(dob.getYear(),dob.getMonth(),dob.getDay()));
				callableStatement.setString(8, data[8]);//nationality
				callableStatement.setString(9, data[9]);//address	
				callableStatement.setString(10, data[10]);//city
				callableStatement.setString(11, data[11]);//state
				callableStatement.setString(12, data[12]);//country		
				callableStatement.setString(13, data[13]);//mobile no
				callableStatement.setString(14, data[14]);//gender		
				callableStatement.setString(15, "User");//role		
				
				callableStatement.addBatch();
			    
				
			}
			
			callableStatement.executeBatch();
			message="Record Added";
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return message;
	}
	

}
