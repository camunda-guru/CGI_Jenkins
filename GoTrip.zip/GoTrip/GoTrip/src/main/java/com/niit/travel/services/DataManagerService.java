package com.niit.travel.services;

import com.niit.travel.entities.Country;
import com.niit.travel.facades.IDataManager;

public class DataManagerService {
private IDataManager iDataManager;

public String addCountry(Country country)
{
	return iDataManager.addCountry(country);
}
public Country getCountryById(String Id)
{
	return iDataManager.getCountryById(Id);
}
	
}
