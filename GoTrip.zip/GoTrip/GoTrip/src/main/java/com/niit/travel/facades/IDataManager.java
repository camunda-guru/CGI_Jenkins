package com.niit.travel.facades;

import java.util.List;

import com.niit.travel.entities.Country;
import com.niit.travel.entities.Customer;
import com.niit.travel.entities.State;

public interface IDataManager {

 String addCountry(Country country) ;
 List<Country> getCountries();
 Country getCountryById(String Id);
 String addState(State state);
String addCustomers(Customer customer);
 
}
