package com.niit.travel.entities;

public enum Role {
Admin,User
}
