package com.niit.travel.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.travel.dao.DataManager;
import com.niit.travel.entities.Customer;
import com.niit.travel.entities.Gender;
import com.niit.travel.entities.Role;

/**
 * Servlet implementation class AddCustomerServlet
 */
@WebServlet(urlPatterns="/AddCustomerServlet")
public class AddCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  Enumeration enumData =  request.getParameterNames();
		  PrintWriter out =response.getWriter();
		  response.setContentType("text/html");
		  out.println("Field Names......");
		  String fieldName=null;
		  Customer customer=new Customer();
		  customer.setUserName(request.getParameter("userName"));
		  customer.setFirstName(request.getParameter("firstName"));
		  customer.setLastName(request.getParameter("lastName"));
		  customer.setPassword(request.getParameter("password"));	
		  customer.setEmail(request.getParameter("email"));	
		  SimpleDateFormat sformat=new SimpleDateFormat("yyyy-MM-dd");
			Date dob;
			try {
				dob = sformat.parse(request.getParameter("dob"));
				customer.setDob(LocalDate.of(dob.getYear(),dob.getMonth(), dob.getDay()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		  
		  customer.setGender(  Gender.valueOf(request.getParameter("gender")));
		  customer.setCity(request.getParameter("city"));
		customer.setAddress( request.getParameter("address"));
		customer.setState( request.getParameter("state"));
		customer.setCountry( request.getParameter("country"));
		customer.setNationality( request.getParameter("nationality"));
		customer.setMobileNo( request.getParameter("mobileNo"));
		customer.setPinCode(request.getParameter("pinCode"));
		customer.setRole(Role.User);
		
		String message =new DataManager().addCustomers(customer);
		out.println("Response from DAO" + message);
		  
		  while(enumData.hasMoreElements())
		  {
			  fieldName=enumData.nextElement().toString();
			  out.print("<p>"+fieldName);
			  out.println("--->"+request.getParameter(fieldName)+"</p>");
		        
			  
		  }
		  
		
	}

}
