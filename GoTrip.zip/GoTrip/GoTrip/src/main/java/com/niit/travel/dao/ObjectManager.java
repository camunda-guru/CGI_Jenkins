package com.niit.travel.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.niit.travel.entities.Passenger;

public class ObjectManager {

	private static  String message;
	
	public static String addPassenger(Passenger passenger)
	{
		ResourceBundle rb = ResourceBundle.getBundle("com.niit.travel.resources/wandertripdb");
		
		File file =new File(rb.getString("FileName"));
		FileOutputStream fs;
		ObjectOutputStream objStream;
		if(!file.exists())
		{
			try {
				file.createNewFile();
				message="File Created";
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		
		}
		else
		{
			
			try {
				fs = new FileOutputStream(file,true);
				 objStream=new ObjectOutputStream(fs);
				objStream.writeObject(passenger);
				objStream.close();
				fs.close();
				message="Passenger Added";
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return message;
	}
	
	
	public static List<Passenger>  getPassengers()
	{
		List<Passenger> passengerList=new ArrayList<Passenger>();
		
		ResourceBundle rb = ResourceBundle.getBundle("com.niit.wandertrip.resources/wandertripdb");
		
		File file =new File(rb.getString("FileName"));
		ObjectInputStream objStream;
		try {
			FileInputStream fs = new FileInputStream(file);
			
			boolean eof = false;
			Passenger passenger=null;
			while (!eof) {
				if(fs.available()>0)
				 objStream = new ObjectInputStream(fs);
				else
					objStream=null;
			    try {
			    	
			    	passenger=(Passenger) objStream.readObject();
			    	if(passenger!=null)
			    	{
			    	  System.out.println(passenger.getFirstName());
			    	  System.out.println(passenger.getLastName());
			    	  System.out.println(passenger.getDOB().toLocaleString());
			    	if(  passenger.getAadharCardNo()!=null)
			    	  System.out.println(passenger.getAadharCardNo());
			    	else
			    		System.out.println("Secured Data cannot be read....");
			    	}
			        // read and use data
			    } catch (EOFException e) {
			        eof = true;
			        objStream.close();
			        fs.close();
			    } catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   
			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return passengerList;
	}
	
	
	
	
	
	
}
