package com.niit.travel.entities;

public enum Gender {
Male,Female
}
