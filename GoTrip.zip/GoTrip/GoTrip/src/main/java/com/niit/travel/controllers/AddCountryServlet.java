package com.niit.travel.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.travel.dao.DataManager;
import com.niit.travel.entities.Country;

/**
 * Servlet implementation class AddCountryServlet
 */
@WebServlet(urlPatterns="/AddCountryServlet")
public class AddCountryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCountryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String code=request.getParameter("countryCode");
		String name=request.getParameter("countryName");
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		/*
		out.println("Data Received from Client.........");
		out.println("<p>Country Code = "+code+"</p>");
		out.println("<p>Country Name = "+name+"</p>");
		*/
		Country country =new Country();
		country.setCountryId(code);
		country.setName(name);
		String message = new DataManager().addCountry(country);
		out.println("Data Received from Server.................. ");
		out.println("<p>"+message+"</p>");
	}

}
